import { TodoDirective } from './todo.directive';

describe('TodoDirective', () => {
  it('should create an instance', () => {
    const directive = new TodoDirective();
    expect(directive).toBeTruthy();
  });
});
